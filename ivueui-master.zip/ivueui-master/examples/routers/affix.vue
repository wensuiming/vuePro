<style>
    body{
        /*height: 2000px;*/
    }
    .demo-affix{
        width: 100px;
        height: 30px;
        background: #f60;
        color: #fff
    }
</style>
<template>
    <Affix>
        <span class="demo-affix">固定在最顶部</span>
    </Affix>
</template>
<script>
    export default {

    }
</script>
