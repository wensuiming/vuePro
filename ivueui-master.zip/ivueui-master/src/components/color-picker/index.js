import ColorPicker from './color-picker.vue';
export default ColorPicker;