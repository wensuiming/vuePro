import BackTop from './back-top.vue';
export default BackTop;