import Slider from './slider.vue';

export default Slider;