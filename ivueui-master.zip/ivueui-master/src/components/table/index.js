import Table from './table.vue';
export default Table;