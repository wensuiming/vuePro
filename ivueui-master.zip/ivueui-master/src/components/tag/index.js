import Tag from './tag.vue';
export default Tag;