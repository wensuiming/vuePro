<template>
    <ul class="one-dropdown-menu"><slot></slot></ul>
</template>
<script>
    export default {};
</script>
