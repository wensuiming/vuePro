<template>
  <el-container class="container">
    <el-header>
      <div class="right">
        <el-tooltip class="item" effect="dark" content="Top Left 提示文字" placement="right-start">
        <el-button>上左</el-button>
      </el-tooltip>
      </div>
    </el-header>
    <el-main>
      <el-tabs v-model="activeTab" @tab-click="handleClick">
        <el-tab-pane label="管理页" name="first">
          <myForm></myForm>
        </el-tab-pane>
        <el-tab-pane label="管理页" name="second">
          <Table></Table>
        </el-tab-pane>
        <el-tab-pane label="管理页" name="third">管理业</el-tab-pane>
      </el-tabs>

    </el-main>
    <el-footer>footer</el-footer>
  </el-container>
</template>

<script>
import Table from './components/table.vue'
import myForm from './components/form.vue'

export default {
  components: { Table, myForm },
  name: "App",
  data () {
    return {
      activeTab: "first"
    };
  },
  methods: {
    handleClick (tab, event) {
      console.log(tab)
    }
  },
  watch: {
    backColor (newVal, oldVal) {
      console.log(newVal);
    }
  }
};
</script>

<style lang="scss">
html,
body {
  margin: 0;
  padding: 0;
  height: 100%;
  width: 100%;
  text-align: center;
  // background: rgba(0, 0, 0, 0.8)
}
.container {
  width: 100%;
  height: 100%;
}
</style>
