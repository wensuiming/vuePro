<template>
  <el-container>
    <el-header>
      
    </el-header>
    <el-main>main</el-main>
    <el-footer>contact me</el-footer>
  </el-container>
</template>

<script>

export default {
  components: {  },
  data () {
    return {
      tag: '/',
      allDatas: []
    }
  },
  created () {
    console.log(this.$store)
  }
}
</script>

<style scoped lang="scss">
#app {
  display: block;
  text-align: right;
}

.all-wid {
  width: 80%;
}
</style>
